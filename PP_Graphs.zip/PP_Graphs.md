
## Graphs, `networkx` library

#### Graphs

A **graph** or a **network** -- any model/system with:

+ elements = nodes = vertices
+ relations = edges

Can you think of some examples of graphs and networks around us? And in linguistics?

#### Why do we need graphs?

+ visualization
+ network analysis



The `networkx` library ([documentation](https://networkx.github.io/documentation/latest/index.html)) allows us to work with graphs. Not the only library for working with graphs in python ([some other choices](https://wiki.python.org/moin/PythonGraphLibraries)).

#### Networks


```python
!pip install networkx
```


```python
import networkx as nx
```

#### Creating a graph


```python
G = nx.Graph() # an empty graph
G.add_node(1) # adding a node
G.add_nodes_from([2 ,3, 4, 5, 6, 7]) # adding some nodes

G.remove_node(2) # deleting a node

# labeling nodes, using their ids (1,2,3 etc.)
G.add_node(1, label="node_1")
```

Adding relations:


```python
G.add_edge(1,3) # an edge between 1 and 3
G.add_edges_from([(1, 4), (1, 5), (3, 5), (4, 5), (1, 6), (1, 7)]) # multiple edges
G.remove_edge(1, 5) # removing an edge
```

Printing the result:


```python
print('nodes', G.nodes())
print('edges', G.edges())
```

    nodes [1, 3, 4, 5, 6, 7]
    edges [(1, 3), (1, 4), (1, 6), (1, 7), (3, 5), (4, 5)]
    


```python
# the number of neighbors for a node
G.degree(5)
```




    2




```python
# neighbors for each node
for node in G.nodes():
    print (node, G.degree(node))
```

    1 4
    3 2
    4 2
    5 2
    6 1
    7 1
    

Weighted graphs, where the relations are weighted:


```python
# adding the weight

G.add_edge(1, 3, weight=4)
```

We can add the direction of the relation:


```python
dg = nx.DiGraph()
dg.add_weighted_edges_from([(1,4,0.5), (3,1,0.75)]) # from -- to 
```

Can you summarize the types of the graphs?

#### Saving the graph

You can use various formats:

+ csv -- for nodes, for relations
+ gml (Graph Modelling Language) -- text format for graphs
+ graphml — XML format for graphs
+ gexf (Graph Exchange XML Format) — XML format with metadata for graphs (the most extensive).

To save your graph:



```python
nx.write_gexf(G, 'graph_file.gexf')
```

To read a graph:


```python
G1 = nx.read_gexf('graph_file.gexf')
```

#### Visualization

We will use `matplotlib` ([other options](https://networkx.github.io/documentation/networkx-2.2/reference/drawing.html)).



```python
import matplotlib.pyplot as plt 

pos=nx.spring_layout(G)# choosing a layout
nx.draw_networkx_nodes(G, pos, node_color='red', node_size=10) # color and size of the nodes
nx.draw_networkx_edges(G, pos, edge_color='yellow') # color of edges
nx.draw_networkx_labels(G, pos, font_size=20, font_family='Arial')# adding the labels
plt.axis('off') 
plt.show()
```


![png](output_23_0.png)


#### Network analysis

What can we learn from our graph?


```python
# radius -- the minimum eccentricity of any vertex
print(nx.radius(G))

# diameter -- the maximum distance between the pair of vertices
print(nx.diameter(G))

# the number of nodes and edges

print(G.number_of_nodes())
print(G.number_of_edges())

# density

print(nx.density(G))

# assortativity -- a preference for a network's nodes to attach to others that are similar in some way

print(nx.degree_pearson_correlation_coefficient(G))
```

    2
    3
    6
    6
    0.4
    -0.7333333333333333
    

+ **Radius**

+ **Diameter** 

+ **Assortativity coefficient**

+ **Density** - the number of edges divided by the possible number of edges

+ **Degree** – the number of relations

+ **Weighted degree** – the number of relations of a node divided by the total number of relations in the graph

+ **Centrality**:
    + **degree centrality**: the more relations, the more important the node
    + **closeness centrality**: the more central (closer to other nodes), the more important the node
    + **betweenness centrality**: the number of closest paths that go through the node
    + **eigencentrality**: the more friends your neighbors have, the more important you are

[Relevant documentation](https://networkx.github.io/documentation/networkx-2.2/reference/algorithms/centrality.html).


```python
# centrality (importance)

deg = nx.degree_centrality(G)
for nodeid in sorted(deg, key=deg.get, reverse=True):
    print(nodeid)
```

    1
    3
    4
    5
    6
    7
    


```python
b = nx.betweenness_centrality(G)
for nodeid in sorted(b, key=b.get, reverse=True):
    print(nodeid)
```

    1
    3
    4
    5
    6
    7
    


```python
e = nx.eigenvector_centrality(G)
for nodeid in sorted(b, key=b.get, reverse=True):
    print(nodeid)
```

    1
    3
    4
    5
    6
    7
    

**Clustering coefficient** – the probability that the closest neighbors of a node will be connected to each other


```python
print(nx.average_clustering(G))
print(nx.transitivity(G))
```

    0.0
    0
    

**Modularity** shows to what extent the density within communities of a given community structure is higher than the density between communities.

**Community** – sets of nodes densely connected internally.

![](https://focus.ua/files/medvedeva/2016/04/01-11/gofthr.jpg)


```python
from networkx.algorithms import community
```

[Here](https://networkx.github.io/documentation/latest/reference/algorithms/community.html) you can find algorythms for generating communities:


```python
communities_generator = community.girvan_newman(G)
top_level_communities = next(communities_generator)
top_level_communities = next(communities_generator)
next_level_communities = next(communities_generator)
next_level_communities = next(communities_generator)
sorted(map(sorted, next_level_communities))
```




    [[1], [3], [4, 5], [6], [7]]



#### Gephi

Gephi is a program that allows you to create, visualize a graph. If you want a beautiful graph, you can process the data in python, upload it to gephi, and create and visualize the graph there.

#### Using existing data

[Here](http://konect.uni-koblenz.de/) you can find a lot of data for graphs. For example, [here](http://konect.uni-koblenz.de/networks/dolphins) are the results of observations on the New Zealand dolphins — 64 nodes (dolphins), 159 relations (the dolphins were observed together).

Let's upload the data and examine it:



```python
import urllib.request
import tarfile

response = urllib.request.urlopen('http://konect.uni-koblenz.de/downloads/tsv/dolphins.tar.bz2')
zipped = response.read()

with open('dolphins.tar.bz2', 'wb') as f:
    f.write(zipped)
```

The folder dolphins has 3 files:

+ out.dolphins
+ meta.dolphins
+ README.dolphins

We need the first one: rows wih pairwise ids of dolphins that were observed together.


```python
# opening the archieve
tar = tarfile.open("dolphins.tar.bz2")
tar.extractall()
tar.close()

dolphin_G = nx.Graph()

# adding nodes and edges to the graph
with open('dolphins/out.dolphins') as unzipped:
    for indx, line in enumerate(unzipped):
        if indx:
            line = line.strip()
            node_1, node2 = line.split()
            dolphin_G.add_edge(node_1, node2)
```


```python
# Transitivity coefficient

print(nx.transitivity(dolphin_G))
```

    0.3087757313109426
    


```python
# Which dolphin is the most important one in New Zealand?

deg_dolphin = nx.degree_centrality(dolphin_G)
i = 0
for nodeid in sorted(deg_dolphin, key=deg_dolphin.get, reverse=True):
    i += 1
    print(nodeid, round(deg_dolphin[nodeid], 3))
    if i == 10:
        break
```

    15 0.197
    38 0.18
    46 0.18
    34 0.164
    52 0.164
    18 0.148
    21 0.148
    30 0.148
    58 0.148
    14 0.131
    

[Layout options](https://networkx.github.io/documentation/latest/reference/drawing.html#layout):


```python
pos = nx.shell_layout(dolphin_G)
nx.draw_networkx_nodes(dolphin_G, pos, node_color='blue', node_size=1) 
nx.draw_networkx_edges(dolphin_G, pos, edge_color='green')
nx.draw_networkx_labels(dolphin_G, pos, font_size=10, font_family='Arial')
plt.axis('off') 
plt.show()
```


![png](output_44_0.png)



```python
pos = nx.spring_layout(dolphin_G)
nx.draw_networkx_nodes(dolphin_G, pos, node_color='red', node_size=3) 
nx.draw_networkx_edges(dolphin_G, pos, edge_color='green')
nx.draw_networkx_labels(dolphin_G, pos, font_size=10, font_family='Arial')
plt.axis('off') 
plt.show()
```


![png](output_45_0.png)



```python
pos = nx.random_layout(dolphin_G)
nx.draw_networkx_nodes(dolphin_G, pos, node_color='blue', node_size=1) 
nx.draw_networkx_edges(dolphin_G, pos, edge_color='green')
nx.draw_networkx_labels(dolphin_G, pos, font_size=10, font_family='Arial')
plt.axis('off') 
plt.show()
```


![png](output_46_0.png)



```python
# to extract a subgraph

dolphins_sub = ['15', '38', '46']
sub_G = dolphin_G.subgraph(dolphins_sub)
print(sub_G.number_of_nodes())
```

    3
    

#### Graphs and linguistics

You can find a list of relevant papers [here](https://www.cs.upc.edu/~rferrericancho/linguistic_and_cognitive_networks.html) 
